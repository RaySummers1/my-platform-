import Chart from 'chart.js/auto';

document.addEventListener('DOMContentLoaded', () => {
    initChart();
});

async function initChart() {
    const ctx = document.getElementById('revenueChart').getContext('2d');
    const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    const data = [10200, 11500, 10800, 13200, 12900, 14290];

    new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'Monthly Revenue ($)',
                data: data,
                borderColor: '#37d0ff',
                backgroundColor: 'rgba(55, 208, 255, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });
}

// Global scope for HTML onclicks
window.upgradeToPro = async () => {
    const res = await fetch('/api/subs/create-session', { method: 'POST' });
    const { url } = await res.json();
    window.location.href = url;
};
